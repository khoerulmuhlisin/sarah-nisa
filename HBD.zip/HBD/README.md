# hbd
untuk temen kamu yang lagi ultah

untuk buat kartu baru kunjungi `https://yahyaanwar.github.io/hbd/create`

---

## manual

cara pakai: `https://yahyaanwar.github.io/hbd/?params`

ganti `params` dengan parameter


daftar parameter:

**name** (opsional)

nama yang ulang tahun. contoh:

`https://yahyaanwar.github.io/hbd/?name=Jhon Doe`

`https://yahyaanwar.github.io/hbd/?name=["yahya","anwar"]`


**date** (opsional)

tanggal ulang tahun(format: bulan tanggal tahun jam:menit:detik). contoh:

`https://yahyaanwar.github.io/hbd/?date=12 22 1999 15:40`


---

disarankan : `https://yahyaanwar.github.io/hbd/?name=Jhon Doe&date=12 22 1999 15:40`

